<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: sans-serif;
            background-color:rgb(3, 21, 32);

            text-align: center;
        }
        .error-code {
            font-size: 6rem;
            font-weight: bold;
            color: #6c757d;
        }
        .error-message {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: white;
        }
        .btn-home {
            font-size: 1rem;
            border: none;
            background-color: transparent !important;
            color: rgb(25, 115, 175);

        }
    </style>
</head>
<body>
    <div class="error-container">
        <p class="error-message">403 | acceso denegado.</p>
    </div>
</body>
</html>
